
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit cbec0064b5061844a0b59801d18d26ff83477e57
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Sat Feb 18 17:07:29 2023 +0100
        
            test-powerlines: Add more glyphs and colorize
            
            [why]
            The last missing powerline-extra glyphs should also be in this set.
            
            The intermediate line's color is not visible in some terminals.
            
            [note]
            Also fix that E0CF is shown twice.
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
